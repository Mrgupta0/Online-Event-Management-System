package com.oems;

import com.oems.model.*;
import com.oems.repo.*;
import com.oems.service.*;

import java.util.Scanner;

public class Main {
    private static Scanner sc = new Scanner(System.in);
    private static EventService eventService = new EventService();
    private static UserService userService = new UserService();
    private static BookingService bookingService = new BookingService(eventService, userService);

    public static void main(String[] args) {
        seedData();
        while (true) {
            System.out.println("\n--- Online Event Management System ---");
            System.out.println("1. Events CRUD");
            System.out.println("2. Users CRUD");
            System.out.println("3. Bookings");
            System.out.println("4. List All Data");
            System.out.println("0. Exit");
            System.out.print("Choose: ");
            int ch = Integer.parseInt(sc.nextLine());
            switch (ch) {
                case 1: eventsMenu(); break;
                case 2: usersMenu(); break;
                case 3: bookingsMenu(); break;
                case 4:
                    eventService.listAll();
                    userService.listAll();
                    bookingService.listAll();
                    break;
                case 0: System.out.println("Goodbye!"); System.exit(0);
                default: System.out.println("Invalid option");
            }
        }
    }

    private static void seedData() {
        eventService.createEvent(new Event("E1", "Music Concert", "New Delhi", "2025-12-20", 150));
        eventService.createEvent(new Event("E2", "Tech Talk", "Bengaluru", "2025-11-30", 75));
        userService.createUser(new User("U1", "Alice", "alice@example.com"));
        userService.createUser(new User("U2", "Bob", "bob@example.com"));
    }

    private static void eventsMenu() {
        while (true) {
            System.out.println("\n-- Events Menu --");
            System.out.println("1. Create Event");
            System.out.println("2. View Event");
            System.out.println("3. Update Event");
            System.out.println("4. Delete Event");
            System.out.println("5. List Events");
            System.out.println("0. Back");
            System.out.print("Choose: ");
            int ch = Integer.parseInt(sc.nextLine());
            switch (ch) {
                case 1:
                    System.out.print("ID: "); String id = sc.nextLine();
                    System.out.print("Title: "); String title = sc.nextLine();
                    System.out.print("Location: "); String loc = sc.nextLine();
                    System.out.print("Date (YYYY-MM-DD): "); String date = sc.nextLine();
                    System.out.print("Capacity: "); int cap = Integer.parseInt(sc.nextLine());
                    eventService.createEvent(new Event(id, title, loc, date, cap));
                    break;
                case 2:
                    System.out.print("Event ID: "); System.out.println(eventService.getEvent(sc.nextLine()));
                    break;
                case 3:
                    System.out.print("Event ID: "); String uid = sc.nextLine();
                    System.out.print("New Title: "); String nt = sc.nextLine();
                    System.out.print("New Location: "); String nl = sc.nextLine();
                    System.out.print("New Date: "); String nd = sc.nextLine();
                    System.out.print("New Capacity: "); int nc = Integer.parseInt(sc.nextLine());
                    eventService.updateEvent(new Event(uid, nt, nl, nd, nc));
                    break;
                case 4:
                    System.out.print("Event ID: "); eventService.deleteEvent(sc.nextLine());
                    break;
                case 5:
                    eventService.listAll();
                    break;
                case 0: return;
                default: System.out.println("Invalid");
            }
        }
    }

    private static void usersMenu() {
        while (true) {
            System.out.println("\n-- Users Menu --");
            System.out.println("1. Create User");
            System.out.println("2. View User");
            System.out.println("3. Update User");
            System.out.println("4. Delete User");
            System.out.println("5. List Users");
            System.out.println("0. Back");
            System.out.print("Choose: ");
            int ch = Integer.parseInt(sc.nextLine());
            switch (ch) {
                case 1:
                    System.out.print("ID: "); String id = sc.nextLine();
                    System.out.print("Name: "); String name = sc.nextLine();
                    System.out.print("Email: "); String email = sc.nextLine();
                    userService.createUser(new User(id, name, email));
                    break;
                case 2:
                    System.out.print("User ID: "); System.out.println(userService.getUser(sc.nextLine()));
                    break;
                case 3:
                    System.out.print("User ID: "); String uid = sc.nextLine();
                    System.out.print("New Name: "); String nn = sc.nextLine();
                    System.out.print("New Email: "); String ne = sc.nextLine();
                    userService.updateUser(new User(uid, nn, ne));
                    break;
                case 4:
                    System.out.print("User ID: "); userService.deleteUser(sc.nextLine());
                    break;
                case 5:
                    userService.listAll();
                    break;
                case 0: return;
                default: System.out.println("Invalid");
            }
        }
    }

    private static void bookingsMenu() {
        while (true) {
            System.out.println("\n-- Bookings Menu --");
            System.out.println("1. Create Booking");
            System.out.println("2. View Booking");
            System.out.println("3. Cancel Booking");
            System.out.println("4. List Bookings");
            System.out.println("0. Back");
            System.out.print("Choose: ");
            int ch = Integer.parseInt(sc.nextLine());
            switch (ch) {
                case 1:
                    System.out.print("Booking ID: "); String bid = sc.nextLine();
                    System.out.print("Event ID: "); String eid = sc.nextLine();
                    System.out.print("User ID: "); String uid = sc.nextLine();
                    System.out.print("Seats: "); int seats = Integer.parseInt(sc.nextLine());
                    bookingService.createBooking(new Booking(bid, eid, uid, seats));
                    break;
                case 2:
                    System.out.print("Booking ID: "); System.out.println(bookingService.getBooking(sc.nextLine()));
                    break;
                case 3:
                    System.out.print("Booking ID: "); bookingService.cancelBooking(sc.nextLine());
                    break;
                case 4:
                    bookingService.listAll();
                    break;
                case 0: return;
                default: System.out.println("Invalid");
            }
        }
    }
}
