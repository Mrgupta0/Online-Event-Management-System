package com.oems.service;

import com.oems.model.Booking;
import com.oems.model.Event;
import com.oems.model.User;
import com.oems.repo.BookingRepository;

import java.util.List;

public class BookingService {
    private BookingRepository repo = new BookingRepository();
    private EventService eventService;
    private UserService userService;

    public BookingService() {}
    public BookingService(EventService es, UserService us) {
        this.eventService = es;
        this.userService = us;
    }

    public void createBooking(Booking b) {
        if (repo.exists(b.getId())) {
            System.out.println("Booking already exists: " + b.getId());
            return;
        }
        Event e = eventService.getEvent(b.getEventId());
        if (e == null) { System.out.println("Event not found: " + b.getEventId()); return; }
        User u = userService.getUser(b.getUserId());
        if (u == null) { System.out.println("User not found: " + b.getUserId()); return; }
        if (!e.hasSpace(b.getSeats())) { System.out.println("Not enough seats available"); return; }
        e.bookSeats(b.getSeats());
        repo.save(b);
        System.out.println("Booking created: " + b);
    }

    public Booking getBooking(String id) {
        return repo.findById(id);
    }

    public void cancelBooking(String id) {
        Booking b = repo.findById(id);
        if (b == null) { System.out.println("Booking not found: " + id); return; }
        Event e = eventService.getEvent(b.getEventId());
        if (e != null) e.cancelSeats(b.getSeats());
        repo.delete(id);
        System.out.println("Cancelled booking: " + id);
    }

    public void listAll() {
        System.out.println("\nBookings:");
        List<Booking> all = repo.findAll();
        if (all.isEmpty()) { System.out.println(" (no bookings)"); return; }
        all.forEach(System.out::println);
    }
}
