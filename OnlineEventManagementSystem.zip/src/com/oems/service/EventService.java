package com.oems.service;

import com.oems.model.Event;
import com.oems.repo.EventRepository;

import java.util.List;

public class EventService {
    private EventRepository repo = new EventRepository();

    public void createEvent(Event e) {
        if (repo.exists(e.getId())) {
            System.out.println("Event with id already exists: " + e.getId());
            return;
        }
        repo.save(e);
        System.out.println("Created: " + e);
    }

    public Event getEvent(String id) {
        Event e = repo.findById(id);
        if (e == null) return null;
        return e;
    }

    public void updateEvent(Event e) {
        Event existing = repo.findById(e.getId());
        if (existing == null) {
            System.out.println("Event not found: " + e.getId());
            return;
        }
        existing.setTitle(e.getTitle());
        existing.setLocation(e.getLocation());
        existing.setDate(e.getDate());
        existing.setCapacity(e.getCapacity());
        repo.save(existing);
        System.out.println("Updated: " + existing);
    }

    public void deleteEvent(String id) {
        if (!repo.exists(id)) {
            System.out.println("Event not found: " + id);
            return;
        }
        repo.delete(id);
        System.out.println("Deleted event: " + id);
    }

    public void listAll() {
        System.out.println("\nEvents:");
        List<Event> all = repo.findAll();
        if (all.isEmpty()) { System.out.println(" (no events)"); return; }
        all.forEach(System.out::println);
    }
}
