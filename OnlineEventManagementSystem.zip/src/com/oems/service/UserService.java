package com.oems.service;

import com.oems.model.User;
import com.oems.repo.UserRepository;

import java.util.List;

public class UserService {
    private UserRepository repo = new UserRepository();

    public void createUser(User u) {
        if (repo.exists(u.getId())) {
            System.out.println("User with id already exists: " + u.getId());
            return;
        }
        repo.save(u);
        System.out.println("Created: " + u);
    }

    public User getUser(String id) {
        return repo.findById(id);
    }

    public void updateUser(User u) {
        User existing = repo.findById(u.getId());
        if (existing == null) {
            System.out.println("User not found: " + u.getId());
            return;
        }
        existing.setName(u.getName());
        existing.setEmail(u.getEmail());
        repo.save(existing);
        System.out.println("Updated: " + existing);
    }

    public void deleteUser(String id) {
        if (!repo.exists(id)) {
            System.out.println("User not found: " + id);
            return;
        }
        repo.delete(id);
        System.out.println("Deleted user: " + id);
    }

    public void listAll() {
        System.out.println("\nUsers:");
        List<User> all = repo.findAll();
        if (all.isEmpty()) { System.out.println(" (no users)"); return; }
        all.forEach(System.out::println);
    }
}
