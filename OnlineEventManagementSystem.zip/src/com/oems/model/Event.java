package com.oems.model;

public class Event {
    private String id;
    private String title;
    private String location;
    private String date;
    private int capacity;
    private int seatsBooked = 0;

    public Event(String id, String title, String location, String date, int capacity) {
        this.id = id;
        this.title = title;
        this.location = location;
        this.date = date;
        this.capacity = capacity;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getLocation() { return location; }
    public String getDate() { return date; }
    public int getCapacity() { return capacity; }
    public int getSeatsBooked() { return seatsBooked; }

    public void setTitle(String title) { this.title = title; }
    public void setLocation(String location) { this.location = location; }
    public void setDate(String date) { this.date = date; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public void bookSeats(int s) { this.seatsBooked += s; }
    public void cancelSeats(int s) { this.seatsBooked -= s; if (this.seatsBooked < 0) this.seatsBooked = 0; }

    public boolean hasSpace(int seats) { return (seatsBooked + seats) <= capacity; }

    @Override
    public String toString() {
        return String.format("Event[id=%s, title=%s, location=%s, date=%s, capacity=%d, booked=%d]",
                id, title, location, date, capacity, seatsBooked);
    }
}
