package com.oems.model;

public class Booking {
    private String id;
    private String eventId;
    private String userId;
    private int seats;

    public Booking(String id, String eventId, String userId, int seats) {
        this.id = id;
        this.eventId = eventId;
        this.userId = userId;
        this.seats = seats;
    }

    public String getId() { return id; }
    public String getEventId() { return eventId; }
    public String getUserId() { return userId; }
    public int getSeats() { return seats; }

    @Override
    public String toString() {
        return String.format("Booking[id=%s, event=%s, user=%s, seats=%d]", id, eventId, userId, seats);
    }
}
