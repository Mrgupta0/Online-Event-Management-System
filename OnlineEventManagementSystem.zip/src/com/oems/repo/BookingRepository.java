package com.oems.repo;

import com.oems.model.Booking;
import java.util.*;

public class BookingRepository {
    private Map<String, Booking> bookings = new HashMap<>();

    public void save(Booking b) { bookings.put(b.getId(), b); }
    public Booking findById(String id) { return bookings.get(id); }
    public void delete(String id) { bookings.remove(id); }
    public List<Booking> findAll() { return new ArrayList<>(bookings.values()); }
    public boolean exists(String id) { return bookings.containsKey(id); }
}
