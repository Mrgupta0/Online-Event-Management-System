package com.oems.repo;

import com.oems.model.Event;
import java.util.*;

public class EventRepository {
    private Map<String, Event> events = new HashMap<>();

    public void save(Event e) { events.put(e.getId(), e); }
    public Event findById(String id) { return events.get(id); }
    public void delete(String id) { events.remove(id); }
    public List<Event> findAll() { return new ArrayList<>(events.values()); }
    public boolean exists(String id) { return events.containsKey(id); }
}
