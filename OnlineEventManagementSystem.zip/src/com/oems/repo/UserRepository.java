package com.oems.repo;

import com.oems.model.User;
import java.util.*;

public class UserRepository {
    private Map<String, User> users = new HashMap<>();

    public void save(User u) { users.put(u.getId(), u); }
    public User findById(String id) { return users.get(id); }
    public void delete(String id) { users.remove(id); }
    public List<User> findAll() { return new ArrayList<>(users.values()); }
    public boolean exists(String id) { return users.containsKey(id); }
}
